package RegularExpression;

import java.util.regex.Pattern;

public class Date {

	public static void main(String[] args) {
String var = "22091996";
		
		if(Pattern.matches("([0-2][0-9]|(3)[0-1])(((0)[0-9])|((1)[0-2]))([0-2][0-9][0-9][0-9])",var))
			System.out.println("format : ddMMyyyy ");
		else if(Pattern.matches("([0-2][0-9][0-9][0-9])(((0)[0-9])|((1)[0-2]))([0-2][0-9]|(3)[0-1])",var))
			System.out.println(" format : yyyyMMdd");
		else if(Pattern.matches("(((0)[0-9])|((1)[0-2]))([0-2][0-9]|(3)[0-1])([0-2][0-9][0-9][0-9])",var))
			System.out.println("format : yyyyMMdd");
		else
			System.out.println("It doesnt suit any of the format");

	}

}
