package RegularExpression;

import java.util.regex.Pattern;

public class Filename {

	public static void main(String[] args) {
		//sould validate the date, which will come in YYYYMMDD format. If date is valid, then accept the file. Otherwise throw an customized exception that should display file name along with invalid date separately
		System.out.println(Pattern.matches("^[A-Z_]*([0-2][0-9][0-9][0-9])(((0)[0-9])|((1)[0-2]))([0-2][0-9]|(3)[0-1])\\.txt$","GDFG_FG19961131.txt"));
		//etin must contain 7 digits and must not contain 7802 or 7801
		System.out.println(Pattern.matches("(^(?:(?!7801|7802).){7}+$)","7278034"));
		//should accept only valid gmail id
		System.out.println(Pattern.matches("^[a-z0-9](\\.?[a-z0-9]){5,}@g(oogle)?mail\\.com$","zabiullahcahcet@gmail.com"));
	
	}

}
