package RegularExpression;

import java.util.regex.Pattern;

public class Hour {
	
	public static void main(String args[]) {
		
		String var = "24:56:00";
		
		System.out.println(Pattern.matches("(((0)[0-9])|((1)[0-2]))|(((0)[0-9])|((1)[0-9])|((2)[0-4]))\\:([0-5][0-9])\\:([0-5][0-9])",var));
		
	}

}
