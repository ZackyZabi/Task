package RegularExpression;

import java.util.regex.Pattern;

public class Institution {

	public static void main(String[] args) {
		String InstitutionTypeName="Independent Provider Network";
		
		String provider_Name=null;
		String input="AMAL,'. ";
		
		if(InstitutionTypeName.equals("Independent Provider Network"))
			{
			boolean flag1=Pattern.matches("[A-Z\\,\\-\\'\\.\\s]*",input);
			if(flag1)
			{
				provider_Name=input;
				//System.out.println("Provider Name of InstitutionType Network is "+provider_Name);
			}
			}
		else
		{
			boolean flag2=Pattern.matches("[,-.'&/()@#:\\s]*", input);
			if(flag2)
			{
				provider_Name=input;
				//System.out.println("Provider Name of InstitutionType Network is "+provider_Name);
			}
		}
		if(provider_Name!=null)
			System.out.println("Provider Name of InstitutionType Network is "+provider_Name);
		else
			System.out.println("Please enter the provider Name in correctly..!");
			
}
}