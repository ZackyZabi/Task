package RegularExpression;

import java.util.regex.Pattern;

public class Mobile {

	public static void main(String[] args) {
		
		String var = "+91-83124 75556";
		
		if(Pattern.matches("^\\+91-[789]\\d{1}\\s\\d{2}\\s\\d{2}\\s\\d{2}\\s\\d{2}",var))
			System.out.println("format1 : +91-XX XX XX XX XX");
		else if(Pattern.matches("^\\+91-[789]\\d{4}\\s\\d{5}",var))
			System.out.println(" format2 : +91-XXXXX XXXXX");
		else if(Pattern.matches("^\\+91-[789]\\d{9}",var))
			System.out.println("format3 : +91-XXXXXXXXXX");
		else if(Pattern.matches("^[789]\\d{9}",var))
			System.out.println(" format4 : XXXXXXXXXX");
		else if(Pattern.matches("^[789]\\d{4}\\s\\d{5}",var))
			System.out.println(" format5 : XXXXX XXXXX");
		else if(Pattern.matches("^[789]\\d{1}\\s\\d{2}\\s\\d{2}\\s\\d{2}\\s\\d{2}",var))
			System.out.println("format6 : XX XX XX XX XX");
		else if(Pattern.matches("^\\+91[789]\\d{9}",var))
			System.out.println("+XXXXXXXXXXXX");
		else
			System.out.println("It doesnt suit any of the format");
			
		
		
		System.out.println(Pattern.matches("^\\d{3}\\-2\\d{6}","232-2657453"));

	}

}
