package RegularExpression;

import java.util.regex.Pattern;

public class Name {

	public static void main(String[] args) {
		
	// contain only lower and uppercase characters, and dot(.) symbol, only one space. It should not contain more than one consecutive space.
	System.out.println(Pattern.matches("[a-zA-Z.]*\\s[a-zA-Z.]*","n.zash sdhfb.v"));
	//consecutive space
	System.out.println(Pattern.matches("[[a-zA-Z.]*\\s?[a-zA-Z.]*]*","n.zash sd hfb.v"));
	// Sould not accept if providerName contains letters except lower and upper case characters. Sould not accept space between words.
	System.out.println(Pattern.matches("[a-zA-Z]*","n.zash sd hfb.v"));
	//It should not be null or blank
	System.out.println(Pattern.matches("^(?=\\s*\\S).*$",""));
	//accept if value is Boolean only.
	System.out.println(Pattern.matches("[true|false|FALSE|TRUE]","true"));
	//providerName must contain at least 1 alphabetical letter
	System.out.println(Pattern.matches("[a-zA-Z]+",""));
	//lastName must contain at least 2 bytes
	System.out.println(Pattern.matches("([a-zA-Z]{2,})","a"));
	//state must be 2 characters in length
	System.out.println(Pattern.matches("[a-zA-Z][a-zA-Z]","a"));
	//zipCode must contain only numeric characters, zipCode must be 5 digits in length
	System.out.println(Pattern.matches("[0-9]{5}","2222"));
	//phoneNumber must not contain 999 or 000 or 911 in the first three digits
	System.out.println(Pattern.matches("^((?!(999|000|911))[0-9]{3}[0-9]{7})","9992222222"));
		
		
		
	}}


