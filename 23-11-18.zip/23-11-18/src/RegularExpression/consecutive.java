package RegularExpression;


import java.util.regex.Pattern;

public class consecutive {

	public static void main(String[] args) {
		String input="dffss";	
		if(Pattern.matches("^((?!iii).)*$", input))
			System.out.println(Pattern.matches("^(?!.*(.)\\1\\1\\1+).*$",input));
		else
			System.out.println("false");

}}
