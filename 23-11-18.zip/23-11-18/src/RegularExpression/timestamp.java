package RegularExpression;

import java.util.regex.Pattern;

public class timestamp {

	public static void main(String[] args) {
		String var= "30022018'T'23:30:33";
		System.out.println(Pattern.matches("(([0-2][0-9]|(3)[0-1])(((0)[0-9])|((1)[0-2]))([0-2][0-9][0-9][0-9]))\\'T'((((0)[0-9])|((1)[0-2]))|(((0)[0-9])|((1)[0-9])|((2)[0-4]))\\:([0-5][0-9])\\:([0-5][0-9]))",var));
			

}
}