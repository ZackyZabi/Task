package SerializationDeserialization;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class Demo 
{
	public static void main(String[] args) throws ClassNotFoundException 
	{
		Doctor doctor = new Doctor();
		
		
		FileOutputStream file;
		ObjectOutputStream out;
		FileInputStream file1;
		ObjectInputStream in;
		try {
			file = new FileOutputStream("abc.txt");
			out=new ObjectOutputStream(file);
			out.writeObject(doctor);
			
			
		} catch (IOException e) {
			e.printStackTrace();
		} 
		

		
		try {
			file1 = new FileInputStream("abc.txt");
			in=new ObjectInputStream(file1);
			doctor = (Doctor)in.readObject();
			System.out.println(doctor);
			
		}
			
		 catch (IOException e) {
			e.printStackTrace();
		} 

	}
}
