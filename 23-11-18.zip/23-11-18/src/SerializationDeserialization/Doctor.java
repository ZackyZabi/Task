package SerializationDeserialization;


import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.Timer;

public class Doctor implements Serializable{
	
	private int doctorId = 2;
	private String DoctorName = "Dr.Prasad";
	private String specialization[] = {"Ortho","ENT"};
	private String availabilityStartTime = "9:30";
	private String availabilityEndTime = "18:30";
	private String joinedDate = "12/12/12";
	private String certifications[] = {"MIOT"};
	private Boolean isBoardCertified = true;
	private String languagesKnown[]= {"English","Hindi"};
	private String degree = "M.B.B.S";
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return DoctorName;
	}
	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}
	public String[] getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String[] specialization) {
		this.specialization = specialization;
	}
	public String getAvailabilityStartTime() {
		return availabilityStartTime;
	}
	public void setAvailabilityStartTime(String availabilityStartTime) {
		this.availabilityStartTime = availabilityStartTime;
	}
	public String getAvailabilityEndTime() {
		return availabilityEndTime;
	}
	public void setAvailabilityEndTime(String availabilityEndTime) {
		this.availabilityEndTime = availabilityEndTime;
	}
	public String getJoinedDate() {
		return joinedDate;
	}
	public void setJoinedDate(String joinedDate) {
		this.joinedDate = joinedDate;
	}
	public String[] getCertifications() {
		return certifications;
	}
	public void setCertifications(String[] certifications) {
		this.certifications = certifications;
	}
	public Boolean getIsBoardCertified() {
		return isBoardCertified;
	}
	public void setIsBoardCertified(Boolean isBoardCertified) {
		this.isBoardCertified = isBoardCertified;
	}
	public String[] getLanguagesKnown() {
		return languagesKnown;
	}
	public void setLanguagesKnown(String[] languagesKnown) {
		this.languagesKnown = languagesKnown;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", DoctorName=" + DoctorName + ", specialization="
				+ Arrays.toString(specialization) + ", availabilityStartTime=" + availabilityStartTime
				+ ", availabilityEndTime=" + availabilityEndTime + ", joinedDate=" + joinedDate + ", certifications="
				+ Arrays.toString(certifications) + ", isBoardCertified=" + isBoardCertified + ", languagesKnown="
				+ Arrays.toString(languagesKnown) + ", degree=" + degree + "]";
	}
	
	
	
	

}
